package cat.barcelonactiva.itacademy.mc24.reflection.p02.classReflection;

import java.lang.reflect.Modifier;

public class ClassReflection {

	public static void infoBasic(Class<?> c) {
		
		System.out.println(c.getSimpleName());
		System.out.println(c.getPackage());
		System.out.println(c.getName());
		
		int idModifiers = c.getModifiers();
		System.out.println(idModifiers);
		
		String nombreModifiers =  Modifier.toString(idModifiers);
		System.out.println(nombreModifiers);
		
		
	}
}
