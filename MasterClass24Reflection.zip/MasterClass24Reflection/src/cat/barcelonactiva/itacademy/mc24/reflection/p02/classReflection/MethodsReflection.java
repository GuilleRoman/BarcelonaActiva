package cat.barcelonactiva.itacademy.mc24.reflection.p02.classReflection;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public class MethodsReflection {

	public static void infoAllMethods(Class<?> c) {

		// Para obtener todos los m�todos p�blicos (inclu�dos los heredados)
		System.out.println("M�todos p�blicos -----------------");
		Method[] methods = c.getMethods();
		for (Method m : methods) {
			infoOneMethod(m);

		}

		// Para obtener todos los m�todos de cualquier �mbito (exclu�dos los hereados)
		System.out.println("M�todos declarados -----------------");
		Method[] declaredMethods = c.getDeclaredMethods();
		for (Method m : declaredMethods) {
			infoOneMethod(m);

		}
	}

	public static void infoParticularMethod(Class<?> c) {

		Method particularMethod;
		// Si el m�todo tiene par�metros, podremos pasar cada uno de sus tipos.class
		// en orden despu�s del nombre

		// Obtener un m�todo p�blico (incluye hereados).
		try {
			particularMethod = c.getMethod("getSueldo");
			infoOneMethod(particularMethod);
		} catch (NoSuchMethodException | SecurityException e) {
			System.err.println(e.getMessage());
		}

		try {
			particularMethod = c.getMethod("setSueldo", float.class);
			infoOneMethod(particularMethod);
		} catch (NoSuchMethodException | SecurityException e) {
			System.err.println(e.getMessage());
		}

		// Obtener m�todos de cualquier �mbito (no incluye heredados).

		try {
			particularMethod = c.getDeclaredMethod("pagaDoble");
			infoOneMethod(particularMethod);
		} catch (NoSuchMethodException | SecurityException e) {
			System.err.println(e.getMessage());
		}

		try {
			particularMethod = c.getDeclaredMethod("sueldoNeto", float.class, float.class);
			infoOneMethod(particularMethod);
		} catch (NoSuchMethodException | SecurityException e) {
			System.err.println(e.getMessage());
		}
	}

	public static void infoOneMethod(Method m) {
		System.out.println("Method --------------------------- " + m.toString());
		System.out.println(m.getName());

		int modifiersInt = m.getModifiers();
		String modifierName = Modifier.toString(modifiersInt);
		System.out.println(modifierName);
		
		System.out.println("Tipo retorno: " + m.getGenericReturnType());

		ExceptionsReflection.ExceptionTypesFromMethods(m);
		
		ParametersReflection.infoAllParametersFromMethod(m);

	}
}
