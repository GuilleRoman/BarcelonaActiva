package cat.barcelonactiva.itacademy.mc24.reflection.p04.tests;

import cat.barcelonactiva.itacademy.mc24.reflection.p01.entities.EntidadEmpleado;
import cat.barcelonactiva.itacademy.mc24.reflection.p02.classReflection.ClassReflection;
import cat.barcelonactiva.itacademy.mc24.reflection.p02.classReflection.ConstructorsReflection;
import cat.barcelonactiva.itacademy.mc24.reflection.p02.classReflection.FieldsReflection;
import cat.barcelonactiva.itacademy.mc24.reflection.p02.classReflection.MethodsReflection;
import cat.barcelonactiva.itacademy.mc24.reflection.p03.instanceReflection.InstanceReflection;

public class Test  {

	
	
	
	public static void main(String[] args) {

		// infoDesdeObjetoValorTest();
		//infoDesdeClassTest();
		infoDesdeObjetoTest();
	}

	private static void infoDesdeObjetoValorTest() {
		
		String valor = "texto libre";
		
		Class<?> classDelValor = valor.getClass();
		
		Class<?> classDelTexto = "texto libre".getClass();
		infoClass(classDelTexto, null);

	}

	private static void infoDesdeClassTest() {
		try {
			Class<?> empleadoInfoClass2 = Class
					.forName("cat.barcelonactiva.itacademy.mc24.reflection.p01.entities.EntidadEmpleado");
			infoClass(empleadoInfoClass2, null);
		} catch (ClassNotFoundException e) {
			System.err.println(e.getMessage());
		}

	}

	private static void infoDesdeObjetoTest() {
		EntidadEmpleado empleado = new EntidadEmpleado(1, "00000000A", "Antonio", "P�rez", "Fern�ndez", 2564f);

		//Class<?> empleadoInfoClass = empleado.getClass();
		Class<? extends EntidadEmpleado> empleadoInfoClass1 = empleado.getClass(); // Por seguridad
		infoClass(empleadoInfoClass1, empleado);

	}

	private static void infoClass(Class<?> c, EntidadEmpleado empleado) {

		//ClassReflection.infoBasic(c);

		//FieldsReflection.infoAllFields(c);
		// FieldsReflection.infoParticularFields(c);

		//MethodsReflection.infoAllMethods(c);
		 //MethodsReflection.infoParticularMethod(c);

		 //ConstructorsReflection.infoAllConstructors(c);
//		
		//InstanceReflection.obtenerValorVariablePrivadaTipoFloat(c, empleado, "sueldo");
//		System.out.println("Sueldo ANTES de ser modificado directamente en la variable privada: " + empleado.getSueldo());
//		 InstanceReflection.aplicarValorVariablePrivadaTipoFloat(c, empleado, "sueldo", 1550f);
//		 System.out.println("Sueldo modificado directamente en la variable privada: " + empleado.getSueldo());

		InstanceReflection.invocaUnMetodo(c, empleado);
	}

}
