package cat.barcelonactiva.itacademy.mc24.reflection.p01.entities;

public class EntidadEmpleado extends EntidadPersona {

	protected EntidadEmpleado(int id) {
		super(id, null, null, null, null);
	}

	public EntidadEmpleado(int id, String nif, String nombre, String apellido1, String apellido2, float sueldo)
			throws ArithmeticException {
		super(id, nif, nombre, apellido1, apellido2);
		this.sueldo = sueldo;
		this.pagaDoble();
		this.sueldoNeto(19, 6);
	}

	public long numeroMatricula; // Campo p�blico

	private float sueldo;

	public float getSueldo() {
		return sueldo;
	}

	public void setSueldo(float sueldo) {
		this.sueldo = sueldo;
	}

	@Override
	public String toString() {
		return "Empleado [sueldo=" + sueldo + "]";
	}

	private float pagaDoble() {
		return sueldo * 2;
	}

	private float sueldoNeto(float porcentajeIrpf, float porcentajeSegSocial) throws ArithmeticException {
		float sueldoNeto = sueldo - ((sueldo * porcentajeIrpf) / 100) - ((sueldo * porcentajeSegSocial) / 100);
		return sueldoNeto;
	}
	

}
