package cat.barcelonactiva.itacademy.mc24.reflection.p02.classReflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Type;

public class ExceptionsReflection {

	public static void ExceptionTypesFromMethods(Method m) {
		
		Type[] types = m.getGenericExceptionTypes();
		if (types != null && types.length > 0)
		{
			System.out.println("****************Exceptiones del m�todo " + m.getName() + " -------------");
			for (Type t : types) {
				System.out.println(t.getTypeName());
			}
			
		}
		
	}

	public static void ExceptionTypesFromConstructors(Constructor<?> c) {
		Type[] types = c.getGenericExceptionTypes();
		if (types != null && types.length > 0)
		{
			System.out.println("****************Exceptiones del constructor " + c.getName() + " -------------");
			for (Type t : types) {
				System.out.println(t.getTypeName());
			}
			
		}
	}
}
