package cat.barcelonactiva.itacademy.mc24.reflection.p03.instanceReflection;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import cat.barcelonactiva.itacademy.mc24.reflection.p01.entities.EntidadEmpleado;

public class InstanceReflection {

	public static void obtenerValorVariablePrivadaTipoFloat(Class<?> c, EntidadEmpleado entidadEmpleado,
			String nombreVariable) {

		
		
		if (entidadEmpleado != null) {
			
			
			
			Field fieldVariable = null;
			float valorObtenido = 0;

			try {
				fieldVariable = c.getDeclaredField(nombreVariable);
				try {
					fieldVariable.setAccessible(true);// Para poder acceder a ella si es privada !!!!!!!!!!!!!!
					valorObtenido = fieldVariable.getFloat(entidadEmpleado);
				} catch (IllegalArgumentException | IllegalAccessException e) {
					System.err.println(e.getMessage());

				}
			} catch (NoSuchFieldException | SecurityException e) {
				System.err.println(e.getMessage());
			}

			System.out.println("Valor de la variable desde reflection: " + valorObtenido);

		}
	}

	public static void aplicarValorVariablePrivadaTipoFloat(Class<?> c, EntidadEmpleado entidadEmpleado,
			String nombreVariable, float valor) {

		if (entidadEmpleado != null) {
			Field fieldVariable = null;

			try {
				fieldVariable = c.getDeclaredField(nombreVariable);
				try {
					fieldVariable.setAccessible(true);// Para poder acceder a ella si es privada !!!!!!!!!!!!!!
					fieldVariable.setFloat(entidadEmpleado, valor);
				} catch (IllegalArgumentException | IllegalAccessException e) {
					System.err.println(e.getMessage());

				}
			} catch (NoSuchFieldException | SecurityException e) {
				System.err.println(e.getMessage());
			}

		}
	}

	public static void invocaUnMetodo(Class<?> c, EntidadEmpleado entidadEmpleado) {

		Method m;
		try {
			m = c.getDeclaredMethod("sueldoNeto", float.class, float.class);

			try {
				m.setAccessible(true);// Para poder acceder al m�todo si es privado !!!!!!!!!!!!!!
				float valorRetorno = (float) m.invoke(entidadEmpleado, 10f, 7f);
				System.out.println(
						"Sueldo neto despu�s de invocar a su m�todo de c�lculo por reflection: " + valorRetorno);
			} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				System.err.println(e.getMessage());
			}
		} catch (NoSuchMethodException | SecurityException e) {
			System.err.println(e.getMessage());
		}

	}

}
