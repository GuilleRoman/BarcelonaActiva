package cat.barcelonactiva.itacademy.mc24.reflection.p02.classReflection;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public class FieldsReflection {
	
	public static void infoAllFields(Class<?> c) {
		Field[] fields;
		// Obtener todas las variables p�blicas
		System.out.println("Variables p�blicas (inclu�das las heredadas) ---------------");
		fields = c.getFields();
		for (Field f : fields) {
			infoOneField(f);
		}

		// Obtener todas las variables con cualquier modificador de �mbito
		System.out.println("Variables de cualquier �mbito (excluye heredados) ---------------");
		fields = c.getDeclaredFields();
		for (Field f : fields) {
			infoOneField(f);
		}
	}

	public static void infoParticularFields(Class<?> c) {
		System.out.println("Buscar una variable concreta (getField) ---------------");
		try {
			Field f = c.getField("sueldo"); // Si no es p�blico, no lo encuentra
			infoOneField(f);
		} catch (NoSuchFieldException | SecurityException e) {
			System.err.println(e.getMessage());
		}

		try {
			Field f = c.getField("numeroMatricula"); // Si no es p�blico, no lo encuentra
			infoOneField(f);
		} catch (NoSuchFieldException | SecurityException e) {
			System.err.println(e.getMessage());
		}

		try {
			Field f = c.getField("campoPublicoEnClassePersona"); // Si no es p�blico, no lo encuentra
			infoOneField(f);
		} catch (NoSuchFieldException | SecurityException e) {
			System.err.println(e.getMessage());
		}
		try {
			Field f = c.getField("campoProtectedEnClassePersona"); // Si no es p�blico, no lo encuentra
			infoOneField(f);
		} catch (NoSuchFieldException | SecurityException e) {
			System.err.println(e.getMessage());
		}
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		System.out.println("Buscar una variable concreta (getDeclaredField) ---------------");
		try {
			Field f = c.getDeclaredField("sueldo"); // Lo encuentra si est� declarado en la clase (da igual el �mbito)
			infoOneField(f);
		} catch (NoSuchFieldException | SecurityException e) {
			System.err.println(e.getMessage());
		}

		try {
			Field f = c.getDeclaredField("numeroMatricula"); // Lo encuentra si est� declarado en la clase (da igual el �mbito)
			infoOneField(f);
		} catch (NoSuchFieldException | SecurityException e) {
			System.err.println(e.getMessage());
		}

		try {
			Field f = c.getDeclaredField("campoPublicoEnClassePersona"); // Lo encuentra si est� declarado en la clase (da igual el �mbito)
			infoOneField(f);
		} catch (NoSuchFieldException | SecurityException e) {
			System.err.println(e.getMessage());
		}
		try {
			Field f = c.getDeclaredField("campoProtectedEnClassePersona"); // Lo encuentra si est� declarado en la clase (da igual el �mbito)
			infoOneField(f);
		} catch (NoSuchFieldException | SecurityException e) {
			System.err.println(e.getMessage());
		}
		
	
	}

	public static void infoOneField(Field f) {
		System.out.println("Field ---------------------------" + f.toString());
		System.out.println(f.getName());

		int modifiersInt = f.getModifiers();
		String modifierName = Modifier.toString(modifiersInt);
		System.out.println(modifierName);

		System.out.println(f.getType());
	}
	

}
