package cat.barcelonactiva.itacademy.mc24.reflection.p02.classReflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.lang.reflect.Type;

public class ParametersReflection {

	public static void infoAllParametersFromMethod(Method m) {
		System.out.println("Par�metros del m�todo " + m.getName() + " -------------");
		System.out.println("N�mero par�metros recibidos: " + m.getParameterCount());
		Parameter[] parameters = m.getParameters();
		for (Parameter p : parameters) {
			System.out.println(p.toString());
			System.out.println(p.getName());
			System.out.println(p.getParameterizedType());
		}

		System.out.println("Tipos de los par�metros del m�todo " + m.getName() + " -------------");

		Type[] typesParameters = m.getGenericParameterTypes();
		for (Type t : typesParameters) {
			System.out.println(t.getTypeName());
		}

	}

	public static void infoAllParametersFromConstructor(Constructor<?> c) {
		System.out.println("Par�metros del constructor " + c.getName() + " -------------");
		System.out.println(c.getParameterCount());
		Parameter[] parameters = c.getParameters();
		for (Parameter p : parameters) {
			System.out.println(p.toString());
			System.out.println(p.getName());
			System.out.println(p.getParameterizedType());
		}

		System.out.println("Tipos de los par�metros del constructor " + c.getName() + " -------------");

		Type[] typesParameters = c.getGenericParameterTypes();
		for (Type t : typesParameters) {
			System.out.println(t.getTypeName());
		}

	}
}
