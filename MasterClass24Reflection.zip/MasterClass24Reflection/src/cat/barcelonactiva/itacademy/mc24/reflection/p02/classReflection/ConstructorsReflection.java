package cat.barcelonactiva.itacademy.mc24.reflection.p02.classReflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

public class ConstructorsReflection {

	public static void infoAllConstructors(Class<?> c) {

		// Recordemos que los constructores no se heredan!!

		// Para obtener todos los constructores p�blicos ()
		System.out.println("Constructores p�blicos -----------------");
		Constructor<?>[] constructors = c.getConstructors();
		for (Constructor<?> co : constructors) {
			infoOneConstructor(co);

		}

		// Para obtener todos los m�todos de cualquier �mbito
		System.out.println("Constructores declarados -----------------");
		Constructor<?>[] declaredConstructors = c.getDeclaredConstructors();
		for (Constructor<?> co : declaredConstructors) {
			infoOneConstructor(co);

		}
	}

	public static void infoOneConstructor(Constructor<?> c) {
		System.out.println("Constructor --------------------------- " + c.toString());
		System.out.println(c.getName());

		int modifiersInt = c.getModifiers();
		String modifierName = Modifier.toString(modifiersInt);

		System.out.println(modifierName);

		ExceptionsReflection.ExceptionTypesFromConstructors(c);
		
		ParametersReflection.infoAllParametersFromConstructor(c);

	}
}
